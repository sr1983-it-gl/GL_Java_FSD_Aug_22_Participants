
public class AbstractionDemoUsingFunctions {

	public static void main(String[] args) {
		
		
		double number = 1000;
		
		double result = Math.sqrt(number);
		
		System.out.println("Square Root for " + number 
				+ " is " + result);
	}
}
