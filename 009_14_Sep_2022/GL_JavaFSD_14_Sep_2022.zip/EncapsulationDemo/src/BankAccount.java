
public class BankAccount {

	private long bankAccountNo;
	
	public void setBankAccountNo(int accNo) {
		
		bankAccountNo = accNo;
	}
}
