
public class Demo {

	public static void main(String[] args) {
		
		BankAccount account1 = new BankAccount();
		
		account1.setBankAccountNo(123456);
		
		account1.setBankAccountNo(234567);
		
//		account1.bankAccountNo = 123456;
//		
//		
//		account1.bankAccountNo = 0;
	}
}
