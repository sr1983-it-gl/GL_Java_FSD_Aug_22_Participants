
public class Aeroplane 
	implements Flyable{

	@Override
	public void fly() {
		
		System.out.println("I got manufactured by human beings"
				+ " and I can fly as well");
		
		// TODO Auto-generated method stub
		
	}

}
