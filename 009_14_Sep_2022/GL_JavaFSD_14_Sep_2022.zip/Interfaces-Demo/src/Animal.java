
public class Animal {

}
