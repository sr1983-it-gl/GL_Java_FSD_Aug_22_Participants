
public class Bird2 
	implements Flyable{

	@Override
	public void fly() {
		
		System.out.println("I have wings and I can fly");
	}

}
