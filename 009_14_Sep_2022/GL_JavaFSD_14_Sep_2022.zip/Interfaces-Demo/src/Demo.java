
public class Demo {

	public static void main(String[] args) {
		
		Eagle eagle1 = new Eagle();
		eagle1.fly();
	}
}
