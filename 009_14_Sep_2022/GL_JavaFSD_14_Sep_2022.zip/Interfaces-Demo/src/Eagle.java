
public class Eagle implements Flyable {

	public void fly() {
		
		System.out.println("I am eagle and I am flying..");
	}
}
