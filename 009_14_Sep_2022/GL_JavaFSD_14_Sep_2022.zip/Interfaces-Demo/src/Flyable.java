
public interface Flyable {

	void fly();
}
