
public class HumanBeing implements Flyable{

	@Override
	public void fly() {
		
		System.out.println("I can fly with a help of aeroplane or helicopter");
		
	}

}
